package com.cg.controller;
//import java.util.HashMap;
import java.util.List;
//import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.UserDetails;
import com.cg.exception.UserDetailsException;
import com.cg.repository.UserDetailsRepository;



@CrossOrigin(origins = "*")
@RestController
@RequestMapping(value ="/api/v1")
public class UserController {

	@Autowired
	private UserDetailsRepository Repo;
	
	// get all students
	@Transactional
	@GetMapping("/user")
	public List<UserDetails> getAllUserDetils(){
		return Repo.findAll();
	}		
	
	// create student rest api
	@Transactional
	@PostMapping("/user")
	
	public UserDetails createUserdetails(@RequestBody UserDetails user) {
		return Repo.save(user);
	}
	
	// get student by id rest api
	@Transactional
	@GetMapping("/user/{id}")
	public <X> ResponseEntity<UserDetails> getUserDetailsById(@PathVariable int id) {
		UserDetails user = Repo.findById(id)
				.orElseThrow(() -> new UserDetailsException ("Employee not exist with id :" + id));
		return ResponseEntity.ok(user);
	}
	
	// updatestudent rest api
	@Transactional
	@PutMapping("/user/{id}")
	public ResponseEntity<UserDetails> updateUserDetails(@PathVariable int id, @RequestBody UserDetails userdetails){
		UserDetails user = Repo.findById(id)
				.orElseThrow(() -> new UserDetailsException ("Employee not exist with id :" + id));
		
		user.setName(userdetails.getName());
		user.setDate_of_Birth(userdetails.getDate_of_Birth());
		user.setGender(userdetails.getGender());
		user.setMobile(userdetails.getMobile());
		user.setAddress(userdetails.getAddress());
		
		
		com.cg.entities.UserDetails updatedUserDetails = Repo.save(user);
		return ResponseEntity.ok(updatedUserDetails);
	}
	
	// delete student rest api
	@Transactional
	@DeleteMapping("/user/{id}")
	public ResponseEntity<HttpStatus> deleteUserDetails(@PathVariable int id){
		UserDetails user = Repo.findById(id)
				.orElseThrow(() -> new UserDetailsException ("Employee not exist with id :" + id));
		
		Repo.delete(user);
//		Map<String, Boolean> response = new HashMap<>();
//		response.put("deleted", Boolean.TRUE);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	
}