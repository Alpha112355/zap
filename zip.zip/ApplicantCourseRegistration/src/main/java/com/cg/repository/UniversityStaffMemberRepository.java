package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.entities.UniversityStaffMember;

@Repository
public interface UniversityStaffMemberRepository extends JpaRepository<UniversityStaffMember , Integer > {
	public UniversityStaffMember addStaffmember(int staffId );
	public UniversityStaffMember  updateStaffmember(int staffId);
	public UniversityStaffMember viewStaffMember(int staffId);
	public UniversityStaffMember removeStaffMember(int staffId);
	public List<UniversityStaffMember> viewAllStaffMember();

}
