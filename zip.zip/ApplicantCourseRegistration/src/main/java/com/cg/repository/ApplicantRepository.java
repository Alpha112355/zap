package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.entities.Applicant;

@Repository
public interface ApplicantRepository extends JpaRepository<Applicant, Integer>{
	public Applicant addApplicant(Applicant applicant);
	public Applicant updateApplicant(Applicant applicant);
	public Applicant deleteApplicant(int applicantId);
	public Applicant veiwApplicant(int applicantId);
	public Applicant veiwAllApplicantByStatus(int applicant);
	
	
	
	

}
