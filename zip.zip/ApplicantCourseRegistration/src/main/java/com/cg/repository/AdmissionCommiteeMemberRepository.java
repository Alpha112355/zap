package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.entities.AdmissionCommiteeMember;

@Repository
public interface AdmissionCommiteeMemberRepository extends JpaRepository<AdmissionCommiteeMember, Integer>{
	public AdmissionCommiteeMember addCommiteemember(AdmissionCommiteeMember admiComm);
	public AdmissionCommiteeMember updateCommiteeMember(AdmissionCommiteeMember admiComm);
	public AdmissionCommiteeMember viewCommiteeMember(int adminId);
	public void removeCommiteeMember(int adminId);
	public List<AdmissionCommiteeMember> viewAllCommiteeMember();
}
