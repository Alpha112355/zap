package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.entities.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Integer>{
	public Course addCourse(Course courseName);
	public Course updateCourse(int courseId);
	public Course removeCourse(Course courseName);
	public Course viewCourse(int courseId);
	public List<Course> viewAllCourseByCourseId(int courseId);

}
