package com.cg.entities;

public enum AdmissionStatus {
	APPLIED,
	PENDING,
	CONFORMED,
	REJECTED;

}
