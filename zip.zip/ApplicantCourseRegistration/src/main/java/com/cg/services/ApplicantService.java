package com.cg.services;

import org.springframework.stereotype.Service;
import com.cg.entities.Applicant;

@Service
public interface ApplicantService {
	Applicant addApplicant(Applicant applicant);
	Applicant updateApplicant(Applicant applicant);
	Applicant deleteApplicant(int applicantId);
	Applicant veiwApplicant(int applicantId); 
	Applicant veiwAllApplicantsByStatus(int applicantId);
	

}
