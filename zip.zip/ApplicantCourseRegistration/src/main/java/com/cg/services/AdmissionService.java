package com.cg.services;

import java.util.List;
import org.springframework.stereotype.Service;
import com.cg.entities.Admission;

@Service
public interface AdmissionService {
	public Admission addAdmission(Admission admin);
	public Admission updateAdmission(Admission admin);
	public Admission cancleAdmission(int admissionId);
	public List<Admission> showAllAdmissionByCourseId(int courseId);
}
