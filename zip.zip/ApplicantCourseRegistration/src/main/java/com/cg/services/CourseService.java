package com.cg.services;

import java.util.List;
import org.springframework.stereotype.Service;
import com.cg.entities.Course;

@Service
public interface CourseService {
	public Course addCourse(Course courseName);
	public Course updateCourse(int courseId);
	public Course removeCourse(Course courseName);
	public Course viewCourse(int courseId);
	public List<Course> viewAllCourseByCourseId(int courseId);


}
