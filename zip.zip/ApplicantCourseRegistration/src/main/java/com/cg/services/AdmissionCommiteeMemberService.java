package com.cg.services;

import java.util.List;
import org.springframework.stereotype.Service;
import com.cg.entities.AdmissionCommiteeMember;

@Service
public interface AdmissionCommiteeMemberService {
	public AdmissionCommiteeMember addCommiteemember(AdmissionCommiteeMember admiComm);
	public AdmissionCommiteeMember updateCommiteeMember(AdmissionCommiteeMember admiComm);
	public AdmissionCommiteeMember viewCommiteeMember(int adminId);
	public void removeCommiteeMember(int adminId);
	public List<AdmissionCommiteeMember> viewAllCommiteeMember();
}
