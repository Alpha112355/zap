package com.cg.services;

import java.util.List;
import org.springframework.stereotype.Service;
//import com.cg.entities.Course;
import com.cg.entities.UniversityStaffMember;



@Service
public interface UniversityStaffMemberService {
	public UniversityStaffMember addStaffmember(int staffId );
	public UniversityStaffMember  updateStaffmember(int staffId);
	public UniversityStaffMember viewStaffMember(int staffId);
	public UniversityStaffMember removeStaffMember(int staffId);
//	public Course addCourse(Course courseName);
//	public Course updateCourse(int courseId);
//	public Course removeCourse(Course course);
	public List<UniversityStaffMember> viewAllStaffMember();

}
