package com.cg.servicesImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Applicant;
import com.cg.repository.ApplicantRepository;
import com.cg.services.ApplicantService;

public class ApplicantServiceImpl implements ApplicantService{
	@Autowired
	ApplicantRepository Repo;
	

	@Override
	@Transactional
	public Applicant addApplicant(Applicant applicant) {
		Applicant appli = Repo.addApplicant(applicant);
		return appli;
	}

	@Override
	@Transactional
	public Applicant updateApplicant(Applicant applicant) {
		Applicant appli = Repo.updateApplicant(applicant);
		return appli;
	}

	@Override
	@Transactional
	public Applicant deleteApplicant(int applicantId) {
		Applicant applicant = null;
		applicant = Repo.deleteApplicant(applicantId);
		return applicant;
	}

	@Transactional
	@Override
	public Applicant veiwApplicant(int applicantId) {
		Applicant applicant = null;
		applicant = Repo.veiwApplicant(applicantId);
		return applicant;
	}

	@Transactional
	@Override
	public Applicant veiwAllApplicantsByStatus(int applicantId) {
		Applicant applicant = null;
		applicant =Repo.veiwAllApplicantByStatus(applicantId);
		return applicant;
	}

	
}
