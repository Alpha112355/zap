package com.cg.servicesImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.cg.entities.AdmissionCommiteeMember;
import com.cg.repository.AdmissionCommiteeMemberRepository;
import com.cg.services.AdmissionCommiteeMemberService;

public class AdmissionCommiteeMemberServiceImpl implements AdmissionCommiteeMemberService{
	@Autowired
	AdmissionCommiteeMemberRepository Repo;

	@Transactional
	@Override
	public AdmissionCommiteeMember addCommiteemember(AdmissionCommiteeMember admiComm) {
		AdmissionCommiteeMember member = Repo.addCommiteemember(admiComm);
		return member;
	}

	@Transactional
	@Override
	public AdmissionCommiteeMember updateCommiteeMember(AdmissionCommiteeMember admiComm) {
		AdmissionCommiteeMember member = Repo.updateCommiteeMember(admiComm);
		return member;
	}

	@Transactional
	@Override
	public AdmissionCommiteeMember viewCommiteeMember(int adminId) {
		AdmissionCommiteeMember member = null;
		member = Repo.viewCommiteeMember(adminId);
		return member;
	}

	@Transactional
	@Override
	public void removeCommiteeMember(int adminId) {
		Repo.removeCommiteeMember(adminId);
		
	}

	@Transactional
	@Override
	public List<AdmissionCommiteeMember> viewAllCommiteeMember() {
		List<AdmissionCommiteeMember> member = Repo.viewAllCommiteeMember();
		return member;
	}

}
