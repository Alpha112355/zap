package com.cg.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

//import com.cg.entities.Course;
import com.cg.entities.UniversityStaffMember;
import com.cg.repository.UniversityStaffMemberRepository;
import com.cg.services.UniversityStaffMemberService;

public class UniversityStaffMemberServiceImpl implements UniversityStaffMemberService {
	@Autowired
	UniversityStaffMemberRepository Repo;

	@Transactional
	@Override
	public UniversityStaffMember addStaffmember(int staffId) {
		UniversityStaffMember staff = null;
		staff = Repo.addStaffmember(staffId);
		return staff;
	}

	@Transactional
	@Override
	public UniversityStaffMember updateStaffmember(int staffId) {
		UniversityStaffMember staff = null;
		staff = Repo.updateStaffmember(staffId);
		return staff;
	}

	@Transactional
	@Override
	public UniversityStaffMember viewStaffMember(int staffId) {
		UniversityStaffMember staff =null;
		staff = Repo.viewStaffMember(staffId);
		return staff;
	}

	@Transactional
	@Override
	public UniversityStaffMember removeStaffMember(int staffId) {
		UniversityStaffMember staff = null;
		staff = Repo.removeStaffMember(staffId);
		return staff;
	}

//	@Transactional
//	@Override
//	public Course addCourse(Course courseName) {
//		Course course = Repo.addCourse(course , Course.class);
//		return null;
//	}
//
//	@Override
//	public Course updateCourse(int courseId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Course removeCourse(Course course) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Transactional
	@Override
	public List<UniversityStaffMember> viewAllStaffMember() {
		List<UniversityStaffMember> staff = Repo.viewAllStaffMember();
		return staff;
	}

}
