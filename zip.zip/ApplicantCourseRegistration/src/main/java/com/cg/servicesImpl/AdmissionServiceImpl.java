package com.cg.servicesImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.cg.entities.Admission;
import com.cg.repository.AdmissionRepository;
import com.cg.services.AdmissionService;


public class AdmissionServiceImpl implements AdmissionService{
	@Autowired
	AdmissionRepository Repo;

	@Transactional
	@Override
	public Admission addAdmission(Admission admin) {
		Admission admi = Repo.addAdmission(admin);
		return admi;
	}

	@Transactional
	@Override
	public Admission updateAdmission(Admission admin) {
		Admission admi = Repo.updateAdmission(admin);
		return admi;
	}

	@Transactional
	@Override
	public Admission cancleAdmission(int admissionId) {
		Admission admission = null;
		admission = Repo.cancleAdmission(admissionId);
		return admission;
	}	

	@Transactional
	@Override
	public List<Admission> showAllAdmissionByCourseId(int courseId) {
		List<Admission> AdmissionList = Repo.findAll();
		return AdmissionList;
	}

}
