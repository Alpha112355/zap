package com.cg.servicesImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.cg.entities.Course;
import com.cg.repository.CourseRepository;
import com.cg.services.CourseService;

public class CourseServiceImpl implements CourseService {
	@Autowired
	CourseRepository Repo;

	@Transactional
	@Override
	public Course addCourse(Course courseName) {
		Course course = Repo.addCourse(courseName) ;
		return course;
	}

	@Override
	public Course updateCourse(int courseId) {
		Course course = null;
		course = Repo.updateCourse(courseId);
		return course;
	}

	@Override
	public Course removeCourse(Course courseName) {
		Course course = Repo.removeCourse(courseName);
		return course;
	}

	@Override
	public Course viewCourse(int courseId) {
		Course course = null;
		course = Repo.viewCourse(courseId);
		return course;
	}

	@Override
	public List<Course> viewAllCourseByCourseId(int courseId) {
		List<Course> course = Repo.viewAllCourseByCourseId(courseId);
		return course;
	}

}
